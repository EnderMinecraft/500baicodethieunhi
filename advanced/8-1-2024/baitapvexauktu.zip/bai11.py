name = input("What is your name? ")
name = name.split()
print(f"Tên : {name[2]}, Đệm: {name[1]}")