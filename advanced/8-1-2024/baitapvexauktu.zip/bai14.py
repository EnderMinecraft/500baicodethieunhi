brkstr = input("Enter a string: ")
brk = brkstr.split()
print(" ".join(brk))