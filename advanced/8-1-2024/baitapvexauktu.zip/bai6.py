strin = input("string1: ")
strin2 = input("string2: ")
print(len(strin.split())+len(strin2.split()))