numl = input("Enter integers: ")
numl = numl.split()
print(f"Count: {len(numl)}")
print(" ".join(numl))