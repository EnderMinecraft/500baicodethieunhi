datei = input("Date(dd/mm/yyyy): ")
datei = datei.split("/")
print(f"Ngày {datei[0]} tháng {datei[1]} năm {datei[2]}")