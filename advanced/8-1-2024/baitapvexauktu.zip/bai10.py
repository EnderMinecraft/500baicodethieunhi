import math
num = input("num(2): ")
nlist = num.split()
nlist.sort()
print(math.gcd(int(nlist[0]), int(nlist[1])))